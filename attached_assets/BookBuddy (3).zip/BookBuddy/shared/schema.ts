import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name"),
  bio: text("bio"),
  avatar: text("avatar"),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  reviews: many(reviews),
  readingChallenges: many(readingChallenges)
}));

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  isAdmin: true,
});

// Book model
export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  author: text("author").notNull(),
  description: text("description").notNull(),
  coverImage: text("cover_image"),
  price: doublePrecision("price"),
  isbn: text("isbn"),
  publishedDate: timestamp("published_date"),
  publisher: text("publisher"),
  genres: text("genres").array(),
  pages: integer("pages"),
  language: text("language"),
  featured: boolean("featured").default(false),
});

export const booksRelations = relations(books, ({ many }) => ({
  reviews: many(reviews)
}));

export const insertBookSchema = createInsertSchema(books).omit({
  id: true,
});

// Review model
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  bookId: integer("book_id").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  aiEnhanced: text("ai_enhanced"),
  likesCount: integer("likes_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviewsRelations = relations(reviews, ({ one }) => ({
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id]
  }),
  book: one(books, {
    fields: [reviews.bookId],
    references: [books.id]
  })
}));

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  likesCount: true,
  createdAt: true,
});

// Reading challenge model
export const readingChallenges = pgTable("reading_challenges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  targetBooks: integer("target_books").notNull(),
  completedBooks: integer("completed_books").default(0),
  year: integer("year").notNull(),
});

export const readingChallengesRelations = relations(readingChallenges, ({ one }) => ({
  user: one(users, {
    fields: [readingChallenges.userId],
    references: [users.id]
  })
}));

export const insertChallengeSchema = createInsertSchema(readingChallenges).omit({
  id: true,
  completedBooks: true,
});

// Reading List model
export const readingLists = pgTable("reading_lists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  bookId: integer("book_id").notNull(),
  addedAt: timestamp("added_at").defaultNow(),
  status: text("status").notNull().default("want-to-read"),
});

export const readingListsRelations = relations(readingLists, ({ one }) => ({
  user: one(users, {
    fields: [readingLists.userId],
    references: [users.id]
  }),
  book: one(books, {
    fields: [readingLists.bookId],
    references: [books.id]
  })
}));

export const insertReadingListSchema = createInsertSchema(readingLists).omit({
  id: true,
  addedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Book = typeof books.$inferSelect;
export type InsertBook = z.infer<typeof insertBookSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type ReadingChallenge = typeof readingChallenges.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;

export type ReadingList = typeof readingLists.$inferSelect;
export type InsertReadingList = z.infer<typeof insertReadingListSchema>;
